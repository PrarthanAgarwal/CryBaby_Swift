import Foundation
import SwiftUI

// Empty configuration file - Font registration removed as we're using system fonts 